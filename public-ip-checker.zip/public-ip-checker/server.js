const express = require("express");
const path = require("path");

const app = express();
const port = process.env.PORT || 3000;

// Render terminates HTTPS at its proxy and forwards the visitor address.
// If you deploy elsewhere, configure trust proxy for your own proxy topology.
app.set("trust proxy", 1);

app.use(express.static(path.join(__dirname, "public")));

app.get("/api/my-ip", (req, res) => {
  res.set("Cache-Control", "no-store");
  res.json({
    ip: req.ip || "Unavailable",
    forwardedProtocol: req.protocol
  });
});

app.listen(port, "0.0.0.0", () => {
  console.log(`IP checker listening on port ${port}`);
});
