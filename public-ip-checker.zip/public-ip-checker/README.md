# Public IP Checker

A small, mobile-friendly Express site. A visitor taps **Show my public IP**;
the browser requests `/api/my-ip`, and the server returns the public IP address
it sees for that request.

This starter does **not** store IP addresses or create a visitor log.

## Run locally

Requires Node.js 20 or newer.

```bash
npm install
npm start
```

Open `http://localhost:3000`.

## Deploy to Render

1. Create a GitHub repository and upload the contents of this folder.
2. In Render, choose **New +** → **Web Service**.
3. Connect the GitHub repository.
4. Set **Build Command** to `npm install`.
5. Set **Start Command** to `npm start`.
6. Choose the free instance option if available, then deploy.
7. Open the `onrender.com` URL Render gives you.

Render's proxy is accounted for with Express `trust proxy` set to one hop.
If deploying behind a different proxy, adjust that setting to match your setup.
